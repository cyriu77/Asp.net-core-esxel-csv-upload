﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CyriuApplication.Models
{
    public class Worker
    {
        public string Personne { get; set; } = "";
        public string PayRoll { get; set; } = "";
        public string Forenames { get; set; } = "";
        public string Surname { get; set; } = "";
        public string Address { get; set; } = "";
        public string Email { get; set; } = "";
    }
}
