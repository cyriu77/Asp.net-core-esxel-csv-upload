﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CyriuApplication.Models;
using ExcelDataReader;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
/*using Magnum.FileSystem;*/

namespace CyriuApplication.Controllers
{
    public class WorkersController : Controller
    {
        [HttpGet]
        public IActionResult Index(List <Worker> workers = null)
        {
            workers = workers == null ? new List<Worker>() : workers;
            return View(workers);
        }
        [HttpPost]
        public IActionResult Index(IFormFile file, [FromServices] IWebHostEnvironment hostingEnvironment)
        {
            string fileName = $"{hostingEnvironment.WebRootPath}\\files\\{file.FileName}";
            using (FileStream fileStream = System.IO.File.Create(fileName))
            {
                file.CopyTo(fileStream);
                fileStream.Flush();
            }
            var workers = this.GetWorkerList(file.FileName);
            return Index(workers);
        }
        
        private List<Worker> GetWorkerList(string fName)
        {
            List<Worker> workers = new List<Worker>();
            var fileName = $"{Directory.GetCurrentDirectory()}{@"\wwwroot\files"}" + "\\" + fName;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = System.IO.File.Open(fileName, FileMode.Open, FileAccess.Read))
            {
                using (var reader=ExcelReaderFactory.CreateReader(stream))
                {
                    while(reader.Read())
                    {
                        workers.Add(new Worker()
                        {
                            Personne = reader.GetValue(0).ToString(),
                            PayRoll = reader.GetValue(1).ToString(),
                            Forenames = reader.GetValue(2).ToString(),
                            Surname = reader.GetValue(3).ToString(),
                            Address = reader.GetValue(4).ToString(),
                            Email = reader.GetValue(5).ToString()
                        });
                    }
                }
            }
            return workers;
        }
    }
}
